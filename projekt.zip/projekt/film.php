<!DOCTYPE html>
<html>
<head>
    <title>Film</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: lightblue;
            padding-top: 50px;
        }
        
        .film-image {
            max-width: 100%;
            margin: 0 auto;
        }

        .film-details {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        if (isset($_GET['naziv'])) {
            $naziv = $_GET['naziv'];

            $xml = simplexml_load_file('filmovi.xml');

            $film = $xml->xpath('//film[naziv="' . $naziv . '"]')[0];
        ?>
        <div class="row justify-content-center">
            <div class="col-lg">
                <div class="film-image text-center">
                    <img src="<?php echo $film->backslika; ?>" alt="Slika filma" class="img-fluid">
                </div>
                <div class="film-details">
                    <h1><?php echo $film->naziv; ?></h1>
                    <div class="row">
                        <div class="col">
                            <p>Godina: <?php echo $film->godina; ?></p>
                        </div>
                        <div class="col">
                            <p>Rating: <?php echo $film->rating; ?></p>
                        </div>
                        <div class="col">
                            <p>Žanr: <?php echo $film->zanr; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        } else {
            echo 'Greška: Film nije pronađen.';
        }
        ?>
    </div>
</body>
</html>
