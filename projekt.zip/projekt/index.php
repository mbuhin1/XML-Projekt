<!DOCTYPE html>
<html>
<head>
    <title>Lista filmova</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        body {
            background-color: #ADD8E6;
            font-family: Arial, sans-serif;
        }

        .container {
            background-color: #ADD8E6;
            max-width: 1500px;
            margin: 0 auto;
        }

        .film-card {
            width: 20%;
            padding: 10px;
            display: inline-block;
            text-align: center;
            border: 1px solid #B8D0FF;
            border-radius: 5px;
            background-color: #ADD8E6;
            margin-bottom: 20px;
        }
        .film-card .card-body {
            background-color: #ADD8E6;
        }
        .clearfix::after {
            content: "";
            display: table;
            clear: both;
        }
        .film-card a {
            color: inherit;
            text-decoration: none;
        }
        h1,h5{
            font-weight: bold
        }
        
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center ">Lista filmova</h1>
        <div class="row">
            <?php
            // Učitavanje XML fajla
            $xml = simplexml_load_file('filmovi.xml');

            // Prikazivanje svih filmova
            foreach ($xml->film as $film) {
                $naziv = $film->naziv;
                $godina = $film->godina;
                $slika = $film->slika;
                $zanr = $film->zanr;
                $rating = $film->rating;

                // Prikazivanje pojedinačnog filma u Bootstrap kartici
                echo '<div class="film-card">';
                echo '<a href="film.php?naziv=' . urlencode($naziv) . '">';
                echo '<div class="card">';
                if (!empty($slika)) {
                    echo '<img src="' . $slika . '" class="card-img-top" alt="Slika filma">';
                }
                echo '<div class="card-body">';
                echo '<h5 class="card-title">' . $naziv . '</h5>';
                echo '<p class="card-text">Godina: ' . $godina . '</p>';
                echo '<p class="card-text">Žanr: ' . $zanr . '</p>';
                echo '<p class="card-text">Ocena: ' . $rating . '</p>';
                echo '</div>';
                echo '</div>';
                echo '</a>';
                echo '</div>';

                echo '<div class="clearfix"></div>';
            }
            ?>
        </div>
    </div>
</body>
</html>
